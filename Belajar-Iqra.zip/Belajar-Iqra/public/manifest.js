{
  "name": "Iqra' Galaksi",
  "short_name": "IqraGalaksi",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#0d1b2a",
  "theme_color": "#2563eb",
  "icons": [
    {
      "src": "/icon.png",
      "sizes": "192x192",
      "type": "image/png"
    }
  ]
}
